
import React from "react";
import MariselasSalon from "./MariselasSalon";

function App() {
  return <MariselasSalon />;
}

export default App;
