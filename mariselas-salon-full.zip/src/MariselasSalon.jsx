
import React from "react";

function MariselasSalon() {
  return (
    <main style={{ fontFamily: "sans-serif", textAlign: "center", padding: "2rem", color: "#a83263" }}>
      <img
        src="https://scontent.fcrk1-2.fna.fbcdn.net/v/t39.30808-6/439922459_61574971273131_3064319326550246019_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=RIzvBvdU6gkQ7kNvgFVbkHg&_nc_ht=scontent.fcrk1-2.fna&oh=00_AYBApUK7HRMO1OEKD99Y4k84gC8oOPOeEEvVEK6YaLQu8A&oe=664A4C60"
        alt="Marisela's Logo"
        style={{ width: "120px", height: "120px", borderRadius: "50%", boxShadow: "0 0 10px #ccc" }}
      />
      <h1>Marisela's Beauty Salon</h1>
      <p>Glamorous Styles • Expert Care • Unisex Services</p>

      <section style={{ marginTop: "2rem", textAlign: "left", maxWidth: "600px", margin: "auto" }}>
        <h2>Services</h2>
        <ul>
          <li>Unisex Haircuts</li>
          <li>Color / Highlights / Balayage</li>
          <li>Blowouts / Straightening Services</li>
          <li>Eyebrow / Eyelash Services</li>
          <li>Tanninoplasty Treatments</li>
          <li>Makeup and Hair Services</li>
        </ul>
        <h2 style={{ marginTop: "2rem" }}>Contact & Location</h2>
        <p>📍 1512 Zoo Parkway Unit B, Asheboro, NC</p>
        <p>📞 (336) 318-5560</p>
        <p>📧 mariselacortes0219@gmail.com</p>
      </section>
    </main>
  );
}

export default MariselasSalon;
